To create an environment:
 - conda env create -f environment.yml

To update an environment:
 - conda env update --file environment.yml 


My Environments:

- py312 : standard python installation with my preferred packages
- gf5013: python environment for the GF5013 class

