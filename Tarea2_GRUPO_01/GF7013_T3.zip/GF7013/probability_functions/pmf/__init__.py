# -*- python -*-
# -*- coding: utf-8 -*-
"""
Francisco Hernán Ortega Culaciati
ortega.francisco@uchile.cl
frortega@gmail.com
Departamento de Geofísica - FCFM
Universidad de Chile


Modifications: 

"""
from .pmf_base import pmf_base
from .pmf_multinomial import pmf_multinomial