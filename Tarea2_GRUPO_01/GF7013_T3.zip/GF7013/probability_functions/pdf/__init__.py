# -*- python -*-
# -*- coding: utf-8 -*-
"""
Francisco Hernán Ortega Culaciati
ortega.francisco@uchile.cl
frortega@gmail.com
Departamento de Geofísica - FCFM
Universidad de Chile


Modifications: 

"""
from .pdf_base import pdf_base
from .pdf_uniform_nD import pdf_uniform_nD
from .pdf_normal import pdf_normal
