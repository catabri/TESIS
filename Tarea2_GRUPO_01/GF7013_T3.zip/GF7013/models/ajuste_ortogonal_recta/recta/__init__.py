"""
Francisco Ortega Culaciati
ortega.francisco@uchile.cl
GF7013 - Metodos Inversos Avanzados
Departamento de Geofisica - FCFM - Universidad de Chile 
"""
from .recta import recta_par
from .recta import calc_xy_pred
from .recta import calc_dist_sigma
from .utils import plot_recta